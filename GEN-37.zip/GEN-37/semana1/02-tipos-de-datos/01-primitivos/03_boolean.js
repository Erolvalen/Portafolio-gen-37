/*** TIPOS DE DATOS ==> Booleanos ***/

//==> El tipo boolean tiene sólo dos valores posibles: true y false.
const isBigger = 4 > 1
console.log(isBigger) // true

console.log(typeof isBigger)