// ¿Cuál es el valor de cada comparación después del código a continuación?
/*** NO USES QUOKKA, RÉTATE, APRENDERÁS MÁS Y DOMINARÁS EL TEMA ***/
console.log(5 > 4) // true
console.log(500 <= 100) // false
console.log('banco' < 'barco') // true
console.log(undefined == null) // true
console.log('' == NaN) // false
console.log('2' > '12') // true
console.log(0 === 1) // false
console.log(80 >= 15) // true
console.log('aaa' > 'zzz') // false
console.log(undefined === null) // false
console.log(1 !== 0) // true
console.log(null == '\n0\n') // false '0'
console.log(+'\n0\n' === null) // false 0
console.log(NaN == NaN) // false
console.log('1' >= '10') // false
