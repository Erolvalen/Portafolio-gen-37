export function stringBack(text) {
	console.log(text);
}
