/************************************************/
/* MODULES ==> Módulos en JavaScript desde Node */
/************************************************/

import { stringBack } from './script.js';

stringBack('Ejecutando un módulo de Back');
