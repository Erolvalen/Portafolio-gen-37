/*********************************************/
/* EVENTS ==> Eventos de carga de la página  */
/*********************************************/

// window.alert('hola')
// console.log(document.querySelector('h1'))
// console.log('Estado actual:', document.readyState)

// DOMContentLoaded
// document.addEventListener('DOMContentLoaded', () => {
//   console.log('El DOM está completamente cargado')
//   console.log('Estado actual:', document.readyState)
// })

// load
// window.addEventListener('load', () => {
//   console.log('La página se ha cargado completamente.')
//   console.log('Estado actual:', document.readyState)
// })

// beforeunload / unload
// window.addEventListener('beforeunload', (e) => {
//   e.preventDefault()
//   return 'Hay cambios sin guardar. ¿Salir ahora?'
// })

/**************************/
/* EVENTS ==> Async Defer */
/**************************/
console.log(document.querySelector('h1'));
