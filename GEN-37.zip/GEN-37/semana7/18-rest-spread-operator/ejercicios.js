/***rest operator***/

// 1- Haz una suma con arguments y con rest, observa cuáles son las diferencias

// 2- Haz una función que reciba como parámetro nombre y edad, y muéstralo por consola
// si la función recibe más de esos dos parámetros lo que debes hacer es mostrarlo en una lista

// 3- Haz una función que reciba n parámetros y que retorne un arreglo [[1,2],'ale', false, null, [2,3,4]]

// 4- Haz una función que reciba n parámetros y que retorne un arreglo de una sola dimensión [1,2,'ale', false, null, 2,3,4 ]
// PISTA: Implementa también el rest


/***spread operator***/

// 1- Haz una función que reciba dos arreglos como parámetros y retorne un solo arreglo [1,2,3],[4,5,6] => [1,2,3,4,5,6]
// 2- Haz una función que reciba un arreglo tipo [['h', 'o', 'l', 'a', ' '], ['m', 'u', 'n', 'd', 'o']] y devuelva hola mundo
// 3- Haz una función que reciba n parámetros y que retorne un arreglo de una sola dimensión [1,2,'ale', false, null ]


