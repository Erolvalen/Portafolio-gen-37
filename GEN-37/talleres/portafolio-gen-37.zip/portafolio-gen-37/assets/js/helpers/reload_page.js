function resetToHome() {
	window.location.hash = '#home';
}

export default resetToHome;
